package com.example.superheroes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperheroesApplicationTests {

	@Test
	void contextLoads() {
	}

}
